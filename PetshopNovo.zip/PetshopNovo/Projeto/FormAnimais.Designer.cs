﻿namespace Projeto
{
    partial class FormAnimais
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnLocalizarAnimal = new System.Windows.Forms.Button();
            this.btnCadastrarAnimal = new System.Windows.Forms.Button();
            this.txtIdAnimal = new System.Windows.Forms.TextBox();
            this.txtNomeAnimal = new System.Windows.Forms.TextBox();
            this.txtDataAnimal = new System.Windows.Forms.TextBox();
            this.txtId_Propri_Animal = new System.Windows.Forms.TextBox();
            this.txtRacaAnimal = new System.Windows.Forms.TextBox();
            this.txtEspecieAnimal = new System.Windows.Forms.TextBox();
            this.txtPesoAnimal = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.cbxPelagemAnimal = new System.Windows.Forms.ComboBox();
            this.cbxPorteAnimal = new System.Windows.Forms.ComboBox();
            this.cbxSexoAnimal = new System.Windows.Forms.ComboBox();
            this.btnAtualizarAnimal = new System.Windows.Forms.Button();
            this.btnSairAnimal = new System.Windows.Forms.Button();
            this.btnExcluirAnimal = new System.Windows.Forms.Button();
            this.dgvAnimal = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.dgvAnimal)).BeginInit();
            this.SuspendLayout();
            // 
            // btnLocalizarAnimal
            // 
            this.btnLocalizarAnimal.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLocalizarAnimal.Location = new System.Drawing.Point(160, 38);
            this.btnLocalizarAnimal.Name = "btnLocalizarAnimal";
            this.btnLocalizarAnimal.Size = new System.Drawing.Size(75, 23);
            this.btnLocalizarAnimal.TabIndex = 0;
            this.btnLocalizarAnimal.Text = "Localizar";
            this.btnLocalizarAnimal.UseVisualStyleBackColor = true;
            this.btnLocalizarAnimal.Click += new System.EventHandler(this.btnLocalizarAnimal_Click);
            // 
            // btnCadastrarAnimal
            // 
            this.btnCadastrarAnimal.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCadastrarAnimal.Location = new System.Drawing.Point(781, 113);
            this.btnCadastrarAnimal.Name = "btnCadastrarAnimal";
            this.btnCadastrarAnimal.Size = new System.Drawing.Size(75, 23);
            this.btnCadastrarAnimal.TabIndex = 1;
            this.btnCadastrarAnimal.Text = "Cadastrar";
            this.btnCadastrarAnimal.UseVisualStyleBackColor = true;
            this.btnCadastrarAnimal.Click += new System.EventHandler(this.btnCadastrarAnimal_Click);
            // 
            // txtIdAnimal
            // 
            this.txtIdAnimal.Location = new System.Drawing.Point(12, 41);
            this.txtIdAnimal.Name = "txtIdAnimal";
            this.txtIdAnimal.Size = new System.Drawing.Size(142, 20);
            this.txtIdAnimal.TabIndex = 2;
            // 
            // txtNomeAnimal
            // 
            this.txtNomeAnimal.Location = new System.Drawing.Point(12, 123);
            this.txtNomeAnimal.Name = "txtNomeAnimal";
            this.txtNomeAnimal.Size = new System.Drawing.Size(142, 20);
            this.txtNomeAnimal.TabIndex = 3;
            // 
            // txtDataAnimal
            // 
            this.txtDataAnimal.Location = new System.Drawing.Point(12, 203);
            this.txtDataAnimal.Name = "txtDataAnimal";
            this.txtDataAnimal.Size = new System.Drawing.Size(142, 20);
            this.txtDataAnimal.TabIndex = 4;
            // 
            // txtId_Propri_Animal
            // 
            this.txtId_Propri_Animal.Location = new System.Drawing.Point(255, 41);
            this.txtId_Propri_Animal.Name = "txtId_Propri_Animal";
            this.txtId_Propri_Animal.Size = new System.Drawing.Size(142, 20);
            this.txtId_Propri_Animal.TabIndex = 5;
            // 
            // txtRacaAnimal
            // 
            this.txtRacaAnimal.Location = new System.Drawing.Point(255, 123);
            this.txtRacaAnimal.Name = "txtRacaAnimal";
            this.txtRacaAnimal.Size = new System.Drawing.Size(142, 20);
            this.txtRacaAnimal.TabIndex = 6;
            // 
            // txtEspecieAnimal
            // 
            this.txtEspecieAnimal.Location = new System.Drawing.Point(255, 203);
            this.txtEspecieAnimal.Name = "txtEspecieAnimal";
            this.txtEspecieAnimal.Size = new System.Drawing.Size(142, 20);
            this.txtEspecieAnimal.TabIndex = 7;
            // 
            // txtPesoAnimal
            // 
            this.txtPesoAnimal.Location = new System.Drawing.Point(505, 41);
            this.txtPesoAnimal.Name = "txtPesoAnimal";
            this.txtPesoAnimal.Size = new System.Drawing.Size(142, 20);
            this.txtPesoAnimal.TabIndex = 8;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(12, 25);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(22, 13);
            this.label1.TabIndex = 9;
            this.label1.Text = "Id:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(12, 106);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(43, 13);
            this.label2.TabIndex = 10;
            this.label2.Text = "Nome:";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(252, 25);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(93, 13);
            this.label10.TabIndex = 18;
            this.label10.Text = "Id_proprietário:";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(252, 107);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(41, 13);
            this.label11.TabIndex = 19;
            this.label11.Text = "Raça:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(9, 187);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(108, 13);
            this.label3.TabIndex = 20;
            this.label3.Text = "Data Nascimento:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(252, 187);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(56, 13);
            this.label4.TabIndex = 21;
            this.label4.Text = "Espécie:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(502, 25);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(39, 13);
            this.label5.TabIndex = 22;
            this.label5.Text = "Peso:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(502, 106);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(59, 13);
            this.label6.TabIndex = 23;
            this.label6.Text = "Pelagem:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(703, 25);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(39, 13);
            this.label7.TabIndex = 24;
            this.label7.Text = "Sexo:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(502, 187);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(41, 13);
            this.label8.TabIndex = 25;
            this.label8.Text = "Porte:";
            // 
            // cbxPelagemAnimal
            // 
            this.cbxPelagemAnimal.FormattingEnabled = true;
            this.cbxPelagemAnimal.Items.AddRange(new object[] {
            "Longa",
            "Média",
            "Curta"});
            this.cbxPelagemAnimal.Location = new System.Drawing.Point(505, 122);
            this.cbxPelagemAnimal.Name = "cbxPelagemAnimal";
            this.cbxPelagemAnimal.Size = new System.Drawing.Size(142, 21);
            this.cbxPelagemAnimal.TabIndex = 26;
            // 
            // cbxPorteAnimal
            // 
            this.cbxPorteAnimal.FormattingEnabled = true;
            this.cbxPorteAnimal.Items.AddRange(new object[] {
            "Grande",
            "Médio",
            "Pequeno"});
            this.cbxPorteAnimal.Location = new System.Drawing.Point(505, 203);
            this.cbxPorteAnimal.Name = "cbxPorteAnimal";
            this.cbxPorteAnimal.Size = new System.Drawing.Size(142, 21);
            this.cbxPorteAnimal.TabIndex = 27;
            // 
            // cbxSexoAnimal
            // 
            this.cbxSexoAnimal.FormattingEnabled = true;
            this.cbxSexoAnimal.Items.AddRange(new object[] {
            "Macho ",
            "Fêmea"});
            this.cbxSexoAnimal.Location = new System.Drawing.Point(706, 41);
            this.cbxSexoAnimal.Name = "cbxSexoAnimal";
            this.cbxSexoAnimal.Size = new System.Drawing.Size(142, 21);
            this.cbxSexoAnimal.TabIndex = 28;
            // 
            // btnAtualizarAnimal
            // 
            this.btnAtualizarAnimal.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAtualizarAnimal.Location = new System.Drawing.Point(781, 142);
            this.btnAtualizarAnimal.Name = "btnAtualizarAnimal";
            this.btnAtualizarAnimal.Size = new System.Drawing.Size(75, 23);
            this.btnAtualizarAnimal.TabIndex = 29;
            this.btnAtualizarAnimal.Text = "Atualizar";
            this.btnAtualizarAnimal.UseVisualStyleBackColor = true;
            this.btnAtualizarAnimal.Click += new System.EventHandler(this.btnAtualizarAnimal_Click);
            // 
            // btnSairAnimal
            // 
            this.btnSairAnimal.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSairAnimal.Location = new System.Drawing.Point(781, 200);
            this.btnSairAnimal.Name = "btnSairAnimal";
            this.btnSairAnimal.Size = new System.Drawing.Size(75, 23);
            this.btnSairAnimal.TabIndex = 30;
            this.btnSairAnimal.Text = "Sair";
            this.btnSairAnimal.UseVisualStyleBackColor = true;
            this.btnSairAnimal.Click += new System.EventHandler(this.btnSairAnimal_Click);
            // 
            // btnExcluirAnimal
            // 
            this.btnExcluirAnimal.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExcluirAnimal.Location = new System.Drawing.Point(781, 171);
            this.btnExcluirAnimal.Name = "btnExcluirAnimal";
            this.btnExcluirAnimal.Size = new System.Drawing.Size(75, 23);
            this.btnExcluirAnimal.TabIndex = 31;
            this.btnExcluirAnimal.Text = "Excluir";
            this.btnExcluirAnimal.UseVisualStyleBackColor = true;
            this.btnExcluirAnimal.Click += new System.EventHandler(this.btnExcluirAnimal_Click);
            // 
            // dgvAnimal
            // 
            this.dgvAnimal.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvAnimal.Location = new System.Drawing.Point(12, 230);
            this.dgvAnimal.Name = "dgvAnimal";
            this.dgvAnimal.Size = new System.Drawing.Size(844, 251);
            this.dgvAnimal.TabIndex = 32;
            // 
            // FormAnimais
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(868, 493);
            this.Controls.Add(this.dgvAnimal);
            this.Controls.Add(this.btnExcluirAnimal);
            this.Controls.Add(this.btnSairAnimal);
            this.Controls.Add(this.btnAtualizarAnimal);
            this.Controls.Add(this.cbxSexoAnimal);
            this.Controls.Add(this.cbxPorteAnimal);
            this.Controls.Add(this.cbxPelagemAnimal);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtPesoAnimal);
            this.Controls.Add(this.txtEspecieAnimal);
            this.Controls.Add(this.txtRacaAnimal);
            this.Controls.Add(this.txtId_Propri_Animal);
            this.Controls.Add(this.txtDataAnimal);
            this.Controls.Add(this.txtNomeAnimal);
            this.Controls.Add(this.txtIdAnimal);
            this.Controls.Add(this.btnCadastrarAnimal);
            this.Controls.Add(this.btnLocalizarAnimal);
            this.Name = "FormAnimais";
            this.Text = "FormAnimais";
            this.Load += new System.EventHandler(this.FormAnimais_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvAnimal)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnLocalizarAnimal;
        private System.Windows.Forms.Button btnCadastrarAnimal;
        private System.Windows.Forms.TextBox txtIdAnimal;
        private System.Windows.Forms.TextBox txtNomeAnimal;
        private System.Windows.Forms.TextBox txtDataAnimal;
        private System.Windows.Forms.TextBox txtId_Propri_Animal;
        private System.Windows.Forms.TextBox txtRacaAnimal;
        private System.Windows.Forms.TextBox txtEspecieAnimal;
        private System.Windows.Forms.TextBox txtPesoAnimal;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.ComboBox cbxPelagemAnimal;
        private System.Windows.Forms.ComboBox cbxPorteAnimal;
        private System.Windows.Forms.ComboBox cbxSexoAnimal;
        private System.Windows.Forms.Button btnAtualizarAnimal;
        private System.Windows.Forms.Button btnSairAnimal;
        private System.Windows.Forms.Button btnExcluirAnimal;
        private System.Windows.Forms.DataGridView dgvAnimal;
    }
}